@extends('layout/main-light')

@section('title', 'index')

@section('container')
<div class="container mt-4">
<div class="row">
<div class="col-10">
<h1 class="mt-10">Laravel - Pricing page</h1>
{{ $nama_halaman }}
</div>
</div>
</div>
@endsection
