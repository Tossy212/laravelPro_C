@extends('layout/main')

@section('title', 'index')

@section('container')
<div class="container mt-4">
<div class="row">
<div class="col-10">
<h1 class="mt-10">Laravel - Features page</h1>
</div>
</div>
</div>
@endsection
